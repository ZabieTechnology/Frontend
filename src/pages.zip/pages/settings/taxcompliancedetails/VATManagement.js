import React, { useState, useMemo, useCallback } from 'react';
import {
    Container, Box, Tabs, Tab, Grid, Paper, Typography, Button, TextField,
    InputAdornment, TableContainer, Table, TableHead, TableBody, TableRow,
    TableCell, TableSortLabel, TablePagination, Stack, IconButton
} from '@mui/material';
import { visuallyHidden } from '@mui/utils'; // Accessibility helper
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import KeyboardArrowLeft from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRight from '@mui/icons-material/KeyboardArrowRight';

// ========================================================================
// 1. HELPER FUNCTIONS (Defined ONCE, Before Component)
// ========================================================================

/**
 * Formats a number into a currency string (e.g., $1,234.56).
 * @param {number} value - The number to format.
 * @returns {string} Formatted currency string.
 */
const formatCurrency = (value) => {
    if (isNaN(value) || value === null || value === undefined) return '$0.00';
    // Ensure two decimal places as shown in screenshots
    return `$${value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

/**
 * Creates a data object for an Accounts Receivable table row.
 * @param {string} id - Unique identifier for the row.
 * @param {string} customer - Customer name.
 * @param {number} days1_30 - Amount for 1-30 days overdue.
 * @param {number} days31_60 - Amount for 31-60 days overdue.
 * @param {number} days61_90 - Amount for 61-90 days overdue.
 * @param {number} days90plus - Amount for 90+ days overdue.
 * @returns {object} Row data object.
 */
const createAccReceivableData = (id, customer, days1_30, days31_60, days61_90, days90plus) => {
    const total = days1_30 + days31_60 + days61_90 + days90plus;
    return { id, customer, days1_30, days31_60, days61_90, days90plus, total };
};

/**
 * Comparator function for descending sort order.
 * @param {object} a - First item to compare.
 * @param {object} b - Second item to compare.
 * @param {string} orderBy - Property key to sort by.
 * @returns {number} -1 if b < a, 1 if b > a, 0 if equal or property missing.
 */
function descendingComparator(a, b, orderBy) {
    // Basic check for valid properties
    if (a?.[orderBy] === undefined || b?.[orderBy] === undefined) {
        return 0;
    }
    const valA = a[orderBy];
    const valB = b[orderBy];
    if (valB < valA) return -1;
    if (valB > valA) return 1;
    return 0;
}

/**
 * Returns a comparator function based on the desired sort order ('asc' or 'desc') and property.
 * @param {'asc' | 'desc'} order - Sort direction.
 * @param {string} orderBy - Property key to sort by.
 * @returns {function} Comparator function for Array.sort().
 */
function getComparator(order, orderBy) {
    return order === 'desc'
        ? (a, b) => descendingComparator(a, b, orderBy)
        : (a, b) => -descendingComparator(a, b, orderBy);
}

/**
 * Stable sort function to maintain the original order of elements if they are considered equal by the comparator.
 * @param {Array<object>} array - The array to sort.
 * @param {function} comparator - The comparator function.
 * @returns {Array<object>} The sorted array.
 */
function stableSort(array, comparator) {
    // Defensive Check: Ensure input is an array
    if (!Array.isArray(array)) {
        console.error("stableSort received non-array input:", array);
        return []; // Return empty array if input is invalid
    }
    // Add original index to each element
    const stabilizedThis = array.map((el, index) => [el, index]);
    // Sort based on comparator, falling back to original index for ties
    stabilizedThis.sort((a, b) => {
        try { // Add try-catch around comparator for safety
           const order = comparator(a[0], b[0]);
           if (order !== 0) return order;
           return a[1] - b[1]; // Use original index if comparison is equal
        } catch (error) {
            console.error("Error during comparison in stableSort:", error);
            return 0; // Treat as equal if comparison fails
        }
    });
    // Return only the original elements in the new sorted order
    return stabilizedThis.map((el) => el[0]);
}

// ========================================================================
// 2. CONSTANTS (Defined ONCE, Before Component)
// ========================================================================

/**
 * Configuration for the Accounts Receivable table header cells.
 */
const accReceivableHeadCells = [
    { id: 'customer', numeric: false, label: 'Customer' },
    { id: 'days1_30', numeric: true, label: '1 - 30 Days' },
    { id: 'days31_60', numeric: true, label: '31 - 60 Days' },
    { id: 'days61_90', numeric: true, label: '61 - 90 Days' },
    { id: 'days90plus', numeric: true, label: '90+ Days' },
    { id: 'total', numeric: true, label: 'Total' },
];

/**
 * Initial dummy data for the Accounts Receivable table.
 * Replace this with actual data fetching in a real application.
 */
const initialAccReceivableRows = [
    createAccReceivableData('id1', 'Claudia Alves', 2500, 2500, 2500, 2500),
    createAccReceivableData('id2', 'John Smith', 1800, 0, 3200, 0),
    createAccReceivableData('id3', 'Maria Garcia', 500, 1200, 0, 4000),
    createAccReceivableData('id4', 'David Miller', 3100, 500, 500, 500),
    createAccReceivableData('id5', 'Sophia Jones', 0, 6000, 1500, 0),
    createAccReceivableData('id6', 'Michael Brown', 400, 800, 1200, 1600),
    createAccReceivableData('id7', 'Linda Davis', 7000, 0, 0, 0),
    createAccReceivableData('id8', 'Robert Wilson', 100, 200, 300, 8000),
    createAccReceivableData('id9', 'Patricia Taylor', 1500, 1500, 1500, 1500),
    createAccReceivableData('id10', 'James Anderson', 200, 400, 600, 800),
    createAccReceivableData('id11', 'Barbara Thomas', 900, 1800, 2700, 3600),
    createAccReceivableData('id12', 'Paul Walker', 10, 20, 30, 40),
];


// ========================================================================
// 3. HELPER COMPONENTS (Defined ONCE, Before Component)
// ========================================================================

/**
 * Custom component for rendering only Previous and Next pagination actions.
 * Used by the `TablePagination` component via the `ActionsComponent` prop.
 */
function SimplePaginationActions(props) {
    const { count, page, rowsPerPage, onPageChange } = props;

    // Handler for the Previous Page button click
    const handleBackButtonClick = (event) => {
        onPageChange(event, page - 1); // Material UI's onPageChange expects (event, newPage)
    };

    // Handler for the Next Page button click
    const handleNextButtonClick = (event) => {
        onPageChange(event, page + 1);
    };

    return (
        // Container for the action buttons
        <Box sx={{ flexShrink: 0, ml: 2.5 }}> {/* Adjust margin as needed */}
            {/* Previous Page Button */}
            <IconButton
                onClick={handleBackButtonClick}
                disabled={page === 0} // Disable if on the first page
                aria-label="previous page"
                size="small"
                sx={{ // Styling to match the requested look (blue background)
                    bgcolor: 'primary.main',
                    color: 'white',
                    '&:hover': { bgcolor: 'primary.dark' },
                    '&.Mui-disabled': { bgcolor: 'action.disabledBackground', color: 'action.disabled' },
                    mr: 0.5, // Margin between buttons
                    padding: '4px'
                }}
            >
                <KeyboardArrowLeft />
            </IconButton>
            {/* Next Page Button */}
            <IconButton
                onClick={handleNextButtonClick}
                disabled={page >= Math.ceil(count / rowsPerPage) - 1} // Disable if on the last page
                aria-label="next page"
                size="small"
                sx={{ padding: '4px' }} // Standard styling
            >
                <KeyboardArrowRight />
            </IconButton>
        </Box>
    );
}


// ========================================================================
// 4. MAIN COMPONENT (Defined ONCE here)
// ========================================================================
function DashboardOverview() {
    // --- State ---
    const [tabValue, setTabValue] = useState(0);        // Index of the currently selected top tab
    const [order, setOrder] = useState('asc');          // Sort direction ('asc' or 'desc')
    const [orderBy, setOrderBy] = useState('customer'); // Property to sort by
    const [page, setPage] = useState(0);                // Current table page index (0-based)
    const [rowsPerPage, setRowsPerPage] = useState(8);  // Number of rows per table page
    const [searchQuery, setSearchQuery] = useState(''); // Current text in the search input

    // --- Event Handlers ---
    // Handles changing the top navigation tab
    const handleTabChange = (event, newValue) => {
        setTabValue(newValue);
        // Potentially reset filters/page when changing main tabs
        setSearchQuery('');
        setPage(0);
    };

    // Handles clicking on a table header to request sorting
    const handleRequestSort = useCallback((event, property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
        setPage(0); // Reset to first page when sorting changes
    }, [order, orderBy]); // Dependencies: order, orderBy

    // Handles page change event from TablePagination
    const handleChangePage = useCallback((event, newPage) => {
        setPage(newPage);
    }, []); // No dependencies needed as it only sets state

    // Handles rows per page change event from TablePagination
    const handleChangeRowsPerPage = useCallback((event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0); // Reset to first page
    }, []); // No dependencies needed

    // Handles changes in the search input field
    const handleSearchChange = useCallback((event) => {
        setSearchQuery(event.target.value);
        setPage(0); // Reset page when search query changes
    }, []); // No dependencies needed

    // Placeholder handlers for action buttons
    const handleNewInvoice = () => console.log("New Invoice Clicked");
    const handleNewEstimate = () => console.log("New Estimate Clicked");

    // --- Data Processing (Memoized for performance) ---

    // Memoized calculation for filtering rows based on search query
    const filteredRows = useMemo(() => {
        // Defensive check on initial data
        if (!Array.isArray(initialAccReceivableRows)) {
             console.error("initialAccReceivableRows is not an array!", initialAccReceivableRows);
             return []; // Return empty array if initial data is invalid
        }
        // Start with a copy of the initial rows
        let rows = [...initialAccReceivableRows];
        // Apply filter if there is a search query
        if (searchQuery) {
            const lowerCaseQuery = searchQuery.toLowerCase();
            rows = rows.filter(row =>
                // Check if customer name exists and includes the query
                row.customer && typeof row.customer === 'string' &&
                row.customer.toLowerCase().includes(lowerCaseQuery)
            );
        }
        return rows; // Always returns an array
    }, [searchQuery]); // Re-run only when searchQuery changes

    // Memoized calculation for sorting and slicing rows for the current page
    const visibleRows = useMemo(() => {
        // Sort the filtered rows
        const sortedRows = stableSort(filteredRows, getComparator(order, orderBy));
        // Defensive check on sorted rows
        if (!Array.isArray(sortedRows)) {
           console.error("Error: stableSort did not return an array!", sortedRows);
           return []; // Return empty array if sorting failed
        }
        // Slice the sorted rows for the current page
        try {
            return sortedRows.slice(
                page * rowsPerPage,
                page * rowsPerPage + rowsPerPage
            );
        } catch(error) {
             console.error("Error during slice:", error, { sortedRows, page, rowsPerPage });
             return []; // Return empty array if slicing failed
        }
    }, [order, orderBy, page, rowsPerPage, filteredRows]); // Re-run when sort, page, rowsPerPage, or filtered data changes

    // --- Styles ---
    // Common styles for the top navigation tabs
    const commonTabStyles = {
        borderRadius: '8px', textTransform: 'none', mr: 1, bgcolor: '#f0f0f0', color: '#555',
        minHeight: 'auto', p: '8px 16px',
        '&.Mui-selected': { bgcolor: 'white', color: 'black', fontWeight: 'bold' },
        '& .MuiTabs-indicator': { display: 'none' }, indicator: { display: 'none' },
    };

    // Calculate the number of empty rows needed to fill the last page for consistent table height
    const currentVisibleLength = Array.isArray(visibleRows) ? visibleRows.length : 0;
    // Calculate empty rows needed only if it's not the last page potentially
    const emptyRows = rowsPerPage - currentVisibleLength > 0 ? rowsPerPage - currentVisibleLength : 0;
    const tableRowHeight = 43; // Approximate height for size="small" rows in pixels

    // --- Render Component JSX ---
    return (
        <Container maxWidth="lg" sx={{ mt: 4, mb: 4, bgcolor: '#f9f9f9', p: 3, borderRadius: '12px' }}>

            {/* Section 1: Top Navigation Tabs */}
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                <Tabs value={tabValue} onChange={handleTabChange} aria-label="dashboard tabs" TabIndicatorProps={{ style: { display: 'none' } }} sx={{ minHeight: 'auto', '& .MuiTab-root': { minHeight: 'auto' } }}>
                    <Tab label="Overview" sx={commonTabStyles} />
                    <Tab label="Sales Invoice" sx={commonTabStyles} />
                    <Tab label="Credit Notes" sx={commonTabStyles} />
                    <Tab label="Delivery Challan" sx={commonTabStyles} />
                    <Tab label="Estimate" sx={commonTabStyles} />
                    <Tab label="Other Platforms" sx={commonTabStyles} />
                </Tabs>
            </Box>

            {/* Section 2: Metrics Cards & Action Buttons */}
            <Grid container spacing={3} sx={{ mb: 3 }}>
                 {/* Metric Cards with elevation and centered text */}
                 <Grid item xs={12} sm={6} md={3}> <Paper elevation={1} sx={{ p: 2.5, borderRadius: '8px', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}> <Typography variant="h4" component="div" fontWeight="bold" align="center" gutterBottom>{initialAccReceivableRows.length}</Typography> <Typography variant="body2" color="text.secondary" align="center">Total Invoices</Typography> </Paper> </Grid>
                 <Grid item xs={12} sm={6} md={3}> <Paper elevation={1} sx={{ p: 2.5, borderRadius: '8px', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}> <Typography variant="h4" component="div" fontWeight="bold" color="green" align="center" gutterBottom>{formatCurrency(24500)}</Typography> <Typography variant="body2" color="text.secondary" align="center">Total Sales</Typography> </Paper> </Grid>
                 <Grid item xs={12} sm={6} md={3}> <Paper elevation={1} sx={{ p: 2.5, borderRadius: '8px', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}> <Typography variant="h4" component="div" fontWeight="bold" color="#d32f2f" align="center" gutterBottom>{formatCurrency(3200)}</Typography> <Typography variant="body2" color="text.secondary" align="center">Sales return</Typography> </Paper> </Grid>
                 <Grid item xs={12} sm={6} md={3}> <Paper elevation={1} sx={{ p: 2.5, borderRadius: '8px', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}> <Typography variant="h4" component="div" fontWeight="bold" align="center" gutterBottom>24</Typography> <Typography variant="body2" color="text.secondary" align="center">Yet to Publish</Typography> </Paper> </Grid>
                 {/* Receivables Card */}
                 <Grid item xs={12} md={5} sx={{ mt: { xs: 0, md: 0 } }}> <Paper elevation={1} sx={{ p: 2.5, borderRadius: '8px', height: '100%' }}> <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1 }}> <Typography variant="subtitle1" fontWeight="bold">Total Receivables</Typography> <Typography variant="subtitle1" fontWeight="bold" color="error.main"> 16% <Typography component="span" variant="caption" color="text.secondary" sx={{ verticalAlign: 'middle' }}> Overdue</Typography> </Typography> </Box> <Typography variant="h4" component="div" fontWeight="bold" sx={{ mb: 1.5 }}>{formatCurrency(45750)}</Typography> <Stack spacing={1}> <Box sx={{ display: 'flex', justifyContent: 'space-between' }}> <Typography variant="body2" color="text.secondary">0-30 days</Typography> <Typography variant="body2" fontWeight="medium">{formatCurrency(25000)}</Typography> </Box> <Box sx={{ display: 'flex', justifyContent: 'space-between' }}> <Typography variant="body2" color="text.secondary">31-60 days</Typography> <Typography variant="body2" fontWeight="medium">{formatCurrency(15000)}</Typography> </Box> <Box sx={{ display: 'flex', justifyContent: 'space-between' }}> <Typography variant="body2" color="text.secondary">61-90 days</Typography> <Typography variant="body2" fontWeight="medium">{formatCurrency(5750)}</Typography> </Box> </Stack> </Paper> </Grid>
                 {/* Action Buttons */}
                 <Grid item xs={12} md={3} sx={{ mt: { xs: 2, md: 0 } }}> <Stack spacing={2} sx={{ height: '100%', justifyContent: 'center' }}> <Button variant="contained" startIcon={<AddIcon />} onClick={handleNewInvoice} fullWidth sx={{ backgroundColor: '#1976d2', '&:hover': { backgroundColor: '#115293' }, textTransform: 'none', py: 1, borderRadius: '8px' }}> New Invoice </Button> <Button variant="contained" startIcon={<AddIcon />} onClick={handleNewEstimate} fullWidth sx={{ backgroundColor: '#677FF1', '&:hover': { backgroundColor: '#4f64c8' }, textTransform: 'none', py: 1, borderRadius: '8px' }}> New Estimate </Button> </Stack> </Grid>
            </Grid>

            {/* Section 3: Accounts Receivable Table */}
            <Paper elevation={1} sx={{ bgcolor: 'white', borderRadius: '8px', width: '100%', mb: 2, overflow: 'hidden' }}>
                {/* Table Title and Search Bar */}
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 2 }}>
                     <Typography variant="h6" fontWeight="bold">Accounts Receivable</Typography>
                     <TextField size="small" variant="outlined" placeholder="Search Customer..." value={searchQuery} onChange={handleSearchChange} InputProps={{ startAdornment: (<InputAdornment position="start"><SearchIcon color="action" /></InputAdornment>), sx: { borderRadius: '20px', bgcolor: '#f0f0f0', '& .MuiOutlinedInput-notchedOutline': { border: 'none' } } }} sx={{ width: { xs: '180px', sm: '250px' } }} />
                </Box>
                {/* Table Content */}
                <TableContainer>
                    <Table sx={{ minWidth: 750 }} aria-labelledby="tableTitle" size="small">
                        {/* Table Header */}
                        <TableHead sx={{ bgcolor: '#f5f5f5' }}>
                             <TableRow>
                                {accReceivableHeadCells.map((headCell) => (
                                    <TableCell key={headCell.id} align={headCell.numeric ? 'right' : 'left'} padding={'normal'} sortDirection={orderBy === headCell.id ? order : false} sx={{ fontWeight: 'bold', borderBottom: 'none' }}>
                                        <TableSortLabel active={orderBy === headCell.id} direction={orderBy === headCell.id ? order : 'asc'} onClick={(e) => handleRequestSort(e, headCell.id)}>
                                            {headCell.label}
                                            {orderBy === headCell.id ? (<Box component="span" sx={visuallyHidden}>{order === 'desc' ? 'sorted descending' : 'sorted ascending'}</Box>) : null}
                                        </TableSortLabel>
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        {/* Table Body */}
                        <TableBody>
                            {/* Conditional Rendering: Show rows or 'No results' message */}
                            { Array.isArray(visibleRows) && visibleRows.length > 0 ? (
                                visibleRows.map((row) => (
                                     <TableRow hover key={row.id} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                        <TableCell component="th" scope="row">{row.customer}</TableCell>
                                        <TableCell align="right">{formatCurrency(row.days1_30)}</TableCell>
                                        <TableCell align="right">{formatCurrency(row.days31_60)}</TableCell>
                                        <TableCell align="right">{formatCurrency(row.days61_90)}</TableCell>
                                        <TableCell align="right">{formatCurrency(row.days90plus)}</TableCell>
                                        <TableCell align="right" sx={{ fontWeight: 'medium' }}>{formatCurrency(row.total)}</TableCell>
                                    </TableRow>
                                ))
                            ) : (
                                // Row shown when no data matches filters or data is empty
                                <TableRow>
                                    <TableCell colSpan={accReceivableHeadCells.length} align="center" sx={{ py: 3 }}>
                                        {searchQuery ? "No matching customers found." : "No data available."}
                                    </TableCell>
                                </TableRow>
                            )}
                            {/* Empty rows to maintain table height */}
                            { Array.isArray(visibleRows) && emptyRows > 0 && (
                                <TableRow style={{ height: tableRowHeight * emptyRows }} >
                                     <TableCell colSpan={accReceivableHeadCells.length} />
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>
                {/* Table Pagination Controls */}
                <TablePagination
                    rowsPerPageOptions={[8, 10, 25, 50]}
                    component="div"
                    count={filteredRows.length} // Use length of filtered data for total count
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                    labelRowsPerPage="Items per page:" // Custom label
                    ActionsComponent={SimplePaginationActions} // Custom Prev/Next buttons
                    sx={{ borderTop: '1px solid #e0e0e0' }} // Separator line
                />
            </Paper>
        </Container>
    );
}

// ========================================================================
// 5. EXPORT (Define ONCE here)
// ========================================================================
export default DashboardOverview;
